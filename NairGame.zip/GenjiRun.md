Games theme:
The game I created uses charecters and consepts from the game Overwatch by Blizzard Entertainment. The player plays as the charecter Genji, a cybernetic ninja, from overwatch. Genji after his recent fight is low health and needs healing so its up to the player to help him heal up. 

Getting points and health:
You do this by collecting either small health packs or big health packs. Small health packs gives you 20 points per pack which you will use to win the game. If you collect 10, genji has emassed enough healing to be able to withstand another rocket and gets another life. Also when you collect a small health pack the game speeds up slightly. Big health packs on the other hand are more rare but instantly give genji enough healing to with stand another rocket, giving him another life and giving him 100 points. If you collect a big health pack the game speeds up significantly.

Taking damage:
While genji is collecting healing he also is get chased by enemies who are shooting rocekts. Genji has to avoid these rockets while trying to collect the health packs. If the player collides with a rocket, they lose a life and 40 points. Also if the player collides with a rocket the game slows down slightly.

Deflect power up:
Along with the rockets and health packs there are also powerups which genji can collect. If the player collides with the deflect they are able to use genjis deflect ability. To use this ability the player has to click the key E. If the player collides with the a rocket from the front while defelct is active, it will reflect the rocket in the opposite direction. If the reflected rocket collides with any other non-reflected rockets, it will destroy them. The deflect ability will end after around .8 seconds. At the top of the screen it will show when you are able to use the deflect ability. Genji's model will take a deflecting stance when the deflect ability is active.

Nano Boost power up:
The other power ups which genji is able to collect is the nano boost powerup. This makes genji invinsible and faster for around 1.6 seconds. Genji's model will turn blue while nano boost is active.

Win Condition: 
If the points collected is greater or equal to 400, genji will have enough healing to be satisfied and the player will win. Game will show a victory screen along with the number of small health packs collected, big health packs collected, rockets hit, rockets deflected and rockets destroyed. 

Loss Condition: 
If Genji's health drops to zero, the player will lose. Game will show a defeat screen along with the number of small health packs collected, big health packs collected, rockets hit, rockets deflected and rockets destroyed. 

Note:
While the pause and debug features still exist, the player

Images Cited:

defeat-overwatch.gif: https://tenor.com/view/defeat-overwatch-video-game-defeat-screen-gif-17781733

explosion.gif: https://gifer.com/en/2a9n

GamwWin.gif: https://giphy.com/gifs/JohnLegere-win-overwatch-MTdHR2zeyU4LsiGoc7/tile

genji3-removebg-preview.png: https://overwatch.fandom.com/wiki/Genji#Damage

GenjiDeflect.png: https://www.pngegg.com/en/png-zsrco

hanamuraInside.png: I screen shot this image in the actual overwatch Game on the map Hanamura

HealMini2.png: https://tl.net/forum/games/508637-an-introduction-to-overwatch

healthpack02.png: https://tl.net/forum/games/508637-an-introduction-to-overwatch

NanoGenji-removebg-preview.png: https://www.deviantart.com/plank-69/art/Black-Genji-Blue-Overwatch-574348965

Nanowzmocnienie.png: https://overwatch.fandom.com/pl/wiki/Nanowzmocnienie

Odbicie.png: https://overwatch.fandom.com/pl/wiki/Odbicie

pngegg (1).png: https://www.nicepng.com/ourpic/u2w7a9u2t4u2a9r5_genji-transparent-blue-genji-png/

rocket4-removebg-preview.png: https://blix.gg/skins/overwatch/emotes/Folded_Hands
(Search up "soldier helix rockets")

assets/rocket4-removebg-preview-reverse.png: https://blix.gg/skins/overwatch/emotes/Folded_Hands

Genji Run(1).gif: Made on Canva

Images used:
https://wallpapercrafter.com/545129-hanamura-overwatch-overwatch-christmas-illuminated.html

https://gifer.com/en/8X0Z



